from pydrake.all import ( 
    AddMultibodyPlant,
    MultibodyPlantConfig,
    DiagramBuilder,
    Parser,
    Meshcat,
    AddDefaultVisualization,
    Simulator,
    LogVectorOutput,
    ZeroOrderHold,
    DiscreteTimeDelay
)
from pydrake.multibody.math import SpatialForce
from pydrake.multibody.plant import ExternallyAppliedSpatialForce
from pydrake.systems.primitives import ConstantValueSource
from pydrake.common.value import Value

from drake_controller_wrapper import FeedbackControllerDrakeSimWrapper
from my_controller import FeedbackController   # <-- ADD THIS
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


ur_path = "./ur_description/urdf/ur5e.urdf"
ur_pkg = "./ur_description/package.xml"

# set up a diagram and meshcat viewer
builder = DiagramBuilder()
meshcat = Meshcat()

sim_timestep = 2e-4  # 5000 Hz
ZOH_timestep = 2e-3  # 500 Hz

# initialize the plant with the simulation specific parameters
plant, scene_graph = AddMultibodyPlant(
    MultibodyPlantConfig(time_step=sim_timestep),
    builder=builder
)
parser = Parser(plant)
parser.package_map().AddPackageXml(ur_pkg)
model_idx = parser.AddModels(ur_path)[0]

initial_q  = np.array([0.162774, -1.39593, -1.44978, -1.89947,  1.71143, 3.4145])
initial_qd = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])

plant.Finalize()

# add our feedback controller block into the system diagram
controller       = builder.AddSystem(FeedbackControllerDrakeSimWrapper())
N_delay          = 10
torque_ZOH       = builder.AddSystem(DiscreteTimeDelay(update_sec=ZOH_timestep, delay_time_steps=N_delay, vector_size=6))
measurement_ZOH  = builder.AddSystem(ZeroOrderHold(period_sec=ZOH_timestep, vector_size=12))

# external bias force in X only
external_force = ExternallyAppliedSpatialForce()
external_force.body_index = plant.GetBodyByName("tool0").index()
external_force.F_Bq_W    = SpatialForce(tau=[0.0, 0.0, 0.0], f=[-1.0, 0.0, 0.0])
external_forces = builder.AddSystem(ConstantValueSource(Value([external_force])))
external_forces.name = "External Force on Tool"

# connect ports
builder.Connect(controller.GetOutputPort("tau_m"),          torque_ZOH.get_input_port())
builder.Connect(torque_ZOH.get_output_port(),               plant.get_actuation_input_port())
builder.Connect(plant.get_state_output_port(),              measurement_ZOH.get_input_port())
builder.Connect(measurement_ZOH.get_output_port(),          controller.GetInputPort('robot_state'))
builder.Connect(external_forces.get_output_port(),          plant.get_applied_spatial_force_input_port())

# log data
state_logger   = LogVectorOutput(measurement_ZOH.get_output_port(), builder)
control_logger = LogVectorOutput(torque_ZOH.get_output_port(), builder)

AddDefaultVisualization(builder, meshcat)
diagram = builder.Build()

# set initial conditions
simulator    = Simulator(diagram)
robot_context = diagram.GetMutableSubsystemContext(plant, simulator.get_context())
plant.SetPositions(robot_context,  initial_q)
plant.SetVelocities(robot_context, initial_qd)

initial_tau_control = controller.GetInitialGravity(initial_q, initial_qd)
diagram.GetMutableSubsystemContext(torque_ZOH, simulator.get_context()).SetDiscreteState(
    np.array([initial_tau_control] * (N_delay + 1)).reshape((-1,))
)
diagram.GetMutableSubsystemContext(measurement_ZOH, simulator.get_context()).SetDiscreteState(
    np.array([initial_q, initial_qd]).reshape((-1,))
)

# run simulation
meshcat.StartRecording()
simulator.set_target_realtime_rate(1)
simulator.AdvanceTo(50)
meshcat.PublishRecording()

# retrieve logs
state_log  = state_logger.FindLog(simulator.get_context())
contr_log  = control_logger.FindLog(simulator.get_context())

state_data  = state_log.data().transpose()
contr_data  = contr_log.data().transpose()
state_times = state_log.sample_times()
contr_times = contr_log.sample_times()

np.savetxt("state_data_hard.csv",  state_data,  fmt='%.18e', delimiter=",")
np.savetxt("contr_data_hard.csv",  contr_data,  fmt='%.18e', delimiter=",")
np.savetxt("state_times_hard.csv", state_times, fmt='%.18e', delimiter=",")
np.savetxt("contr_times_hard.csv", contr_times, fmt='%.18e', delimiter=",")

# reconstruct end-effector path
tool_frame = plant.GetFrameByName("tool0")
ee_xyz = np.zeros((len(state_times), 3))
for k in range(len(state_times)):
    qk  = state_data[k, :6]
    qdk = state_data[k, 6:12]
    plant.SetPositionsAndVelocities(robot_context, np.hstack((qk, qdk)))
    ee_xyz[k, :] = tool_frame.CalcPoseInWorld(robot_context).translation()

# -----------------------------
# Joint positions
# -----------------------------
plt.figure(figsize=(10, 6))
for i in range(6):
    plt.plot(state_times, state_data[:, i], label=f"q{i+1}")
plt.xlabel("Time [s]")
plt.ylabel("Joint position [rad]")
plt.title("Joint Positions vs Time (Hard Mode)")
plt.grid(True)
plt.legend()
plt.tight_layout()

# -----------------------------
# Joint velocities
# -----------------------------
plt.figure(figsize=(10, 6))
for i in range(6):
    plt.plot(state_times, state_data[:, 6+i], label=f"qd{i+1}")
plt.xlabel("Time [s]")
plt.ylabel("Joint velocity [rad/s]")
plt.title("Joint Velocities vs Time (Hard Mode)")
plt.grid(True)
plt.legend()
plt.tight_layout()

# -----------------------------
# Torque commands
# -----------------------------
plt.figure(figsize=(10, 6))
for i in range(6):
    plt.plot(contr_times, contr_data[:, i], label=f"tau{i+1}")
plt.axhline( 25.0, color='k', linestyle='--', linewidth=1, label='torque limit')
plt.axhline(-25.0, color='k', linestyle='--', linewidth=1)
plt.xlabel("Time [s]")
plt.ylabel("Torque [Nm]")
plt.title("Joint Torque Commands vs Time (Hard Mode)")
plt.grid(True)
plt.legend()
plt.tight_layout()

# -----------------------------
# End-effector XYZ
# -----------------------------
plt.figure(figsize=(10, 6))
plt.plot(state_times, ee_xyz[:, 0], label="x")
plt.plot(state_times, ee_xyz[:, 1], label="y")
plt.plot(state_times, ee_xyz[:, 2], label="z")
plt.xlabel("Time [s]")
plt.ylabel("Position [m]")
plt.title("End-Effector Position vs Time — X deflects, Y and Z unaffected (Hard Mode)")
plt.grid(True)
plt.legend()
plt.tight_layout()

# -----------------------------
# XY trajectory
# -----------------------------
plt.figure(figsize=(7, 7))
plt.plot(ee_xyz[:, 0], ee_xyz[:, 1], label="actual EE path")
plt.xlabel("X [m]")
plt.ylabel("Y [m]")
plt.title("End-Effector XY Path (Hard Mode)")
plt.axis("equal")
plt.grid(True)
plt.legend()
plt.tight_layout()

plt.show()

# -----------------------------
# 3D plot: Actual vs Desired
# -----------------------------
start_pt = ee_xyz[0, :]
end_pt   = ee_xyz[-1, :]
x0, y0, z0 = start_pt
w = 0.18
h = 0.18
z_rect = z0 + 0.08

desired_waypoints = np.array([
    [x0,     y0,     z0],
    [x0 - w, y0,     z0],
    [x0 - w, y0 - h, z0],
    [x0,     y0 - h, z0],
    [x0,     y0,     z0],
])
center_pt = np.array([x0 - 0.5*w, y0 - 0.5*h, z_rect])

fig = plt.figure(figsize=(11, 8))
ax  = fig.add_subplot(111, projection='3d')
ax.plot(ee_xyz[:, 0], ee_xyz[:, 1], ee_xyz[:, 2],
        color='blue', linewidth=2.5, label='Actual EE path')
ax.plot(desired_waypoints[:, 0], desired_waypoints[:, 1], desired_waypoints[:, 2],
        'k--', linewidth=1.8, label='Desired waypoint path')
ax.scatter(desired_waypoints[:, 0], desired_waypoints[:, 1], desired_waypoints[:, 2],
           color='black', s=35, label='Waypoints')
ax.scatter(start_pt[0], start_pt[1], start_pt[2], color='green', s=90, label='Start')
ax.scatter(end_pt[0],   end_pt[1],   end_pt[2],   color='red',   s=90, label='End')
ax.scatter(center_pt[0], center_pt[1], center_pt[2],
           color='magenta', s=140, marker='x', label='Center')
ax.set_xlabel("X [m]")
ax.set_ylabel("Y [m]")
ax.set_zlabel("Z [m]")
ax.set_title("3D End-Effector Path: Actual vs Desired (Hard Mode — Bias Force in X)")
ax.view_init(elev=25, azim=-60)
ax.legend()
plt.tight_layout()
plt.show()

# -----------------------------
# Step response plot
# -----------------------------
ctrl = FeedbackController()          # <-- creates ctrl so save_step_response_plot works
ctrl.save_step_response_plot("step_response.png", show_plot=True)

# -----------------------------
# Distance to center
# -----------------------------
dist_to_center = np.linalg.norm(ee_xyz - center_pt.reshape(1, 3), axis=1)
closest_idx    = np.argmin(dist_to_center)
print("Center point:",               center_pt)
print("Closest actual EE point:",    ee_xyz[closest_idx])
print("Minimum distance to center:", dist_to_center[closest_idx])
print("Time of closest approach [s]:", state_times[closest_idx])