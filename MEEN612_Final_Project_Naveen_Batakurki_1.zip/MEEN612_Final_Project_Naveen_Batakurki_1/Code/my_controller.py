from pydrake.all import (
    DiagramBuilder,
    MultibodyPlantConfig,
    Parser,
    AddMultibodyPlant,
    JacobianWrtVariable,
)
import numpy as np
import matplotlib.pyplot as plt
import os

print("Loaded my_controller_F_v6_merged.py")


# =========================================================================
# Plant loader
# =========================================================================
def local_load_in_multibody_plant():
    ur_path = "./ur_description/urdf/ur5e.urdf"
    ur_pkg  = "./ur_description/package.xml"

    local_builder = DiagramBuilder()
    local_plant, _ = AddMultibodyPlant(
        MultibodyPlantConfig(time_step=2e-3),
        builder=local_builder
    )
    parser = Parser(local_plant)
    parser.package_map().AddPackageXml(ur_pkg)
    local_model_idx = parser.AddModels(ur_path)[0]
    local_plant.Finalize()
    return local_plant, local_model_idx


# =========================================================================
class FeedbackController:

    # ------------------------------------------------------------------
    def __init__(self, q0=None, tau_limit=None):
        self.plant_, self.model_idx_ = local_load_in_multibody_plant()
        self.plant_context = self.plant_.CreateDefaultContext()

        # ---- frames ----
        self.world_frame = self.plant_.world_frame()
        self.tool_frame  = self.plant_.GetFrameByName("tool0")

        self.nq = self.plant_.num_positions(self.model_idx_)
        self.nv = self.plant_.num_velocities(self.model_idx_)

        # ---- per-joint torque limits ----
        if tau_limit is None:
            self.tau_limit = np.array([150.0, 150.0, 150.0, 28.0, 28.0, 28.0])
        else:
            tau_limit = np.asarray(tau_limit, dtype=float)
            self.tau_limit = (
                np.full(self.nv, tau_limit.item()) if tau_limit.ndim == 0
                else tau_limit.reshape(self.nv)
            )

        # ---- Cartesian stiffness / damping ----
        self.Kp_cart = np.diag([10.0, 16.0, 22.0])
        self.Kd_cart = np.diag([30.0, 22.0, 35.0])

        # ---- Cartesian force soft-saturation ----
        self.F_max = np.array([5.0, 5.0, 7.0])

        # ---- DLS regularisation for Lambda ----
        self.lambda_reg = 5e-2

        # ---- Nullspace posture gains ----
        self.Kp_null = 0.1 * np.diag([2.0, 2.0, 2.0, 1.0, 0.5, 0.2])
        self.Kd_null = 0.1 * np.diag([0.8, 0.8, 0.8, 0.4, 0.2, 0.1])

        # ---- Start-up ramp ----
        self.ramp_time = 2.0

        # ---- Cartesian velocity filter ----
        self.alpha     = 0.15
        self.xdot_filt = np.zeros(3)

        # ---- State initialised on first call ----
        self.q0          = None
        self.x0          = None
        self.initialized = False

        # ---- Logging ----
        self.log_dir      = "controller_logs"
        os.makedirs(self.log_dir, exist_ok=True)
        self.time_log              = []
        self.actual_cartesian_log  = []
        self.desired_cartesian_log = []
        self.log_tau               = []
        self.last_save_time        = -1.0
        self.save_interval         = 0.5

        # ---- Waypoint trajectory ----
        self.waypoints      = None
        self.waypoint_times = None

    # ------------------------------------------------------------------
    def _initialize_from_current_pose(self, x_now):
        self.x0 = np.asarray(x_now, dtype=float).reshape(3,)
        x0, y0, z0 = self.x0

        width  = 0.18
        height = 0.18
        top_right    = np.array([x0,         y0,          z0])
        top_left     = np.array([x0 - width, y0,          z0])
        bottom_left  = np.array([x0 - width, y0 - height, z0])
        bottom_right = np.array([x0,         y0 - height, z0])

        self.waypoints = np.array([
            top_right,
            top_left,
            top_left,
            bottom_left,
            bottom_left,
            bottom_right,
            bottom_right,
            top_right,
            top_right,
        ], dtype=float)

        self.waypoint_times = np.array([
             0.0,
             8.0,
            10.0,
            18.0,
            20.0,
            28.0,
            30.0,
            38.0,
            40.0,
        ], dtype=float)

        self.initialized = True

    # ------------------------------------------------------------------
    def _get_desired_cartesian_state(self, t):
        """Cubic smoothstep interpolation between waypoints."""
        if t <= self.waypoint_times[0]:
            return self.waypoints[0].copy(), np.zeros(3), np.zeros(3)
        if t >= self.waypoint_times[-1]:
            return self.waypoints[-1].copy(), np.zeros(3), np.zeros(3)

        idx = int(np.searchsorted(self.waypoint_times, t, side="right")) - 1
        idx = np.clip(idx, 0, len(self.waypoint_times) - 2)

        t0, t1 = float(self.waypoint_times[idx]), float(self.waypoint_times[idx + 1])
        p0, p1 = self.waypoints[idx], self.waypoints[idx + 1]

        if np.isclose(t0, t1):
            return p1.copy(), np.zeros(3), np.zeros(3)

        a     = np.clip((t - t0) / (t1 - t0), 0.0, 1.0)
        s     =  3*a**2 - 2*a**3
        ds    =  6*a   - 6*a**2
        dds   =  6     - 12*a
        dp    = p1 - p0
        dt    = t1 - t0

        x_des   = p0 + s * dp
        xd_des  = (ds  / dt)    * dp
        xdd_des = (dds / dt**2) * dp
        return x_des, xd_des, xdd_des

    # ------------------------------------------------------------------
    def _compute_lambda_and_jbar(self, J, Mq):
        M_inv   = np.linalg.inv(Mq)
        JMinvJt = J @ M_inv @ J.T
        Lambda  = np.linalg.inv(JMinvJt + self.lambda_reg * np.eye(3))
        J_bar   = M_inv @ J.T @ Lambda
        return Lambda, J_bar, M_inv

    # ------------------------------------------------------------------
    def _save_logs(self):
        if not self.time_log:
            return
        t_arr = np.array(self.time_log)
        np.savetxt(
            os.path.join(self.log_dir, "actual_cartesian_path.csv"),
            np.column_stack((t_arr, np.array(self.actual_cartesian_log))),
            delimiter=",", header="time,x,y,z", comments=""
        )
        np.savetxt(
            os.path.join(self.log_dir, "desired_cartesian_path.csv"),
            np.column_stack((t_arr, np.array(self.desired_cartesian_log))),
            delimiter=",", header="time,x_des,y_des,z_des", comments=""
        )

    # ------------------------------------------------------------------
    def calc_control_effort(self, q, qd, time_now):
        q  = np.asarray(q,  dtype=float).reshape(self.nq,)
        qd = np.asarray(qd, dtype=float).reshape(self.nv,)

        self.plant_context = self.plant_.CreateDefaultContext()
        self.plant_.SetPositionsAndVelocities(
            self.plant_context, np.hstack((q, qd))
        )

        # ---- Dynamics ----
        Mq    = np.asarray(self.plant_.CalcMassMatrix(self.plant_context),               dtype=float)
        Cq    = np.asarray(self.plant_.CalcBiasTerm(self.plant_context),                 dtype=float).reshape(self.nv,)
        tau_g = np.asarray(self.plant_.CalcGravityGeneralizedForces(self.plant_context), dtype=float).reshape(self.nv,)

        # ---- FK ----
        x_now = np.asarray(
            self.tool_frame.CalcPoseInWorld(self.plant_context).translation(),
            dtype=float
        ).reshape(3,)

        # ---- First-call initialisation ----
        if not self.initialized:
            self.q0 = q.copy()
            self._initialize_from_current_pose(x_now)

        # ---- Jacobian ----
        J = np.asarray(
            self.plant_.CalcJacobianPositionVector(
                self.plant_context,
                self.tool_frame,
                np.zeros(3),
                self.world_frame,
                self.world_frame
            ),
            dtype=float
        )

        # ---- Bias acceleration Jdot*qdot ----
        Jdot_v = np.asarray(
            self.plant_.CalcBiasTranslationalAcceleration(
                self.plant_context,
                JacobianWrtVariable.kV,
                self.tool_frame,
                np.zeros(3),
                self.world_frame,
                self.world_frame
            ),
            dtype=float
        ).reshape(3,)

        # ---- Cartesian velocity (filtered) ----
        xdot_raw       = J @ qd
        self.xdot_filt = self.alpha * xdot_raw + (1.0 - self.alpha) * self.xdot_filt

        # ---- Desired state ----
        x_des, xd_des, xdd_des = self._get_desired_cartesian_state(time_now)

        # ---- Start-up ramp ----
        ramp = min(time_now / self.ramp_time, 1.0)
        e_x  = ramp * (x_des  - x_now)
        e_xd = ramp * (xd_des - self.xdot_filt)
        xdd_des_ramped = ramp * xdd_des

        # ---- Cartesian impedance control ----
        Lambda, J_bar, _ = self._compute_lambda_and_jbar(J, Mq)

        xdd_cmd = xdd_des_ramped + self.Kp_cart @ e_x + self.Kd_cart @ e_xd - Jdot_v

        F_task = Lambda @ xdd_cmd
        F_task = np.clip(F_task, -self.F_max, self.F_max)

        tau_task = J.T @ F_task

        N_bar    = np.eye(self.nv) - J.T @ J_bar.T
        tau_null = N_bar @ (
            self.Kp_null @ (self.q0 - q) + self.Kd_null @ (-qd)
        )

        tau_control = tau_task + tau_null + Cq - tau_g
        tau_control = np.clip(tau_control, -self.tau_limit, self.tau_limit)

        # ---- Logging ----
        self.time_log.append(float(time_now))
        self.actual_cartesian_log.append(x_now.copy())
        self.desired_cartesian_log.append(x_des.copy())
        self.log_tau.append(tau_control.copy())

        if time_now - self.last_save_time >= self.save_interval:
            self._save_logs()
            self.last_save_time = time_now

        return tau_control

    # ------------------------------------------------------------------
    def save_torque_plot(self, out_file="joint_torques_v6.png", show_plot=False):
        if not self.log_tau:
            print("No data to plot.")
            return
        t   = np.array(self.time_log)
        tau = np.array(self.log_tau)
        fig, ax = plt.subplots(figsize=(11, 5))
        for i in range(tau.shape[1]):
            ax.plot(t, tau[:, i], label=f"tau{i+1}")
        ax.axhline( self.tau_limit.max(), color="k", ls="--", lw=0.8, label="limit")
        ax.axhline(-self.tau_limit.max(), color="k", ls="--", lw=0.8)
        ax.set_xlabel("Time [s]")
        ax.set_ylabel("Torque [Nm]")
        ax.set_title("Joint Torque Commands — v6 Merged Controller")
        ax.grid(True, alpha=0.4)
        ax.legend(ncol=4)
        fig.tight_layout()
        fig.savefig(out_file, dpi=300, bbox_inches="tight")
        print(f"Saved torque plot -> {out_file}")
        if show_plot:
            plt.show()
        else:
            plt.close(fig)

    # ------------------------------------------------------------------
    def save_cartesian_plot(self, out_file="cartesian_tracking_v6.png", show_plot=True):
        if not self.time_log:
            print("No data to plot.")
            return
        t       = np.array(self.time_log)
        actual  = np.array(self.actual_cartesian_log)
        desired = np.array(self.desired_cartesian_log)
        labels  = ["X", "Y", "Z"]
        fig, axes = plt.subplots(3, 1, figsize=(11, 8), sharex=True)
        for i, ax in enumerate(axes):
            ax.plot(t, desired[:, i], "k--", lw=1.2, label="desired")
            ax.plot(t, actual[:,  i], lw=1.5, label="actual")
            ax.set_ylabel(f"{labels[i]} [m]")
            ax.legend(loc="upper right")
            ax.grid(True, alpha=0.4)
        axes[-1].set_xlabel("Time [s]")
        fig.suptitle("Cartesian Tracking — v6 Merged Controller")
        fig.tight_layout()
        fig.savefig(out_file, dpi=300, bbox_inches="tight")
        print(f"Saved Cartesian tracking plot -> {os.path.abspath(out_file)}")
        if show_plot:
            plt.show()
        else:
            plt.close(fig)

    # ------------------------------------------------------------------
    def save_step_response_plot(self, out_file="step_response.png", show_plot=False):
        """
        Simulate a 1-DOF step response for each Cartesian axis using
        the tuned Kp_cart and Kd_cart gains and plot the result.
        """
        dt      = 0.001
        T_final = 6.0
        t_arr   = np.arange(0, T_final, dt)
        x_step  = 0.1
        labels  = ["X", "Y", "Z"]
        kp_vals = [float(self.Kp_cart[i, i]) for i in range(3)]
        kd_vals = [float(self.Kd_cart[i, i]) for i in range(3)]

        fig, axes = plt.subplots(1, 3, figsize=(14, 4), sharey=False)
        fig.suptitle("Step Response Per Cartesian Axis", fontsize=13)

        for i, ax in enumerate(axes):
            kp   = kp_vals[i]
            kd   = kd_vals[i]
            wn   = np.sqrt(kp)
            zeta = kd / (2.0 * wn)

            # Euler integration of PD step response
            x      = 0.0
            xd     = 0.0
            x_hist = []
            for _ in t_arr:
                xdd = kp * (x_step - x) - kd * xd
                xd += xdd * dt
                x  += xd  * dt
                x_hist.append(x)
            x_hist = np.array(x_hist)

            # Analytical critically-damped reference (only if near zeta=1)
            if abs(zeta - 1.0) < 0.05:
                x_anal = x_step * (1 - (1 + wn * t_arr) * np.exp(-wn * t_arr))
                ax.plot(t_arr, x_anal, "k--", lw=1.2, label="Analytical (zeta=1)")

            ax.plot(t_arr, x_hist, lw=2.0, label="Simulated")
            ax.axhline(x_step, color="gray", lw=0.8, ls=":")
            ax.axhline(0,      color="gray", lw=0.8, ls=":")
            ax.axhspan(0.98 * x_step, 1.02 * x_step,
                       alpha=0.12, color="green", label="+-2% band")

            settled = np.where(np.abs(x_hist - x_step) <= 0.02 * x_step)[0]
            if len(settled):
                t_settle = t_arr[settled[0]]
                ax.axvline(t_settle, color="red", lw=0.9, ls="--",
                           label=f"Ts={t_settle:.2f}s")

            ax.set_title(
                f"Axis {labels[i]}  |  Kp={kp:.1f}, Kd={kd:.1f}\n"
                f"wn={wn:.2f} rad/s,  zeta={zeta:.3f}"
            )
            ax.set_xlabel("Time [s]")
            ax.set_ylabel("Position [m]")
            ax.set_xlim([0, T_final])
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.4)

        fig.tight_layout()
        fig.savefig(out_file, dpi=300, bbox_inches="tight")
        print(f"Saved step response plot -> {out_file}")
        if show_plot:
            plt.show()
        else:
            plt.close(fig)


# =========================================================================
if __name__ == "__main__":
    ctrl = FeedbackController()
    print("FeedbackController v6 loaded successfully.")
    print(f"  nq={ctrl.nq}  nv={ctrl.nv}  tau_limit={ctrl.tau_limit}")