from pydrake.all import ( 
    AddMultibodyPlant,
    MultibodyPlantConfig,
    DiagramBuilder,
    Parser,
    Meshcat,
    AddDefaultVisualization,
    Simulator,
    LogVectorOutput
)

from drake_controller_wrapper import FeedbackControllerDrakeSimWrapper
import numpy as np
import matplotlib.pyplot as plt





ur_path = "./ur_description/urdf/ur5e.urdf"
ur_pkg = "./ur_description/package.xml"

# set up a diagram and meshcat viewer
builder = DiagramBuilder()
meshcat = Meshcat()

# initialize the plant with the simulation specific parameters
plant, scene_graph = AddMultibodyPlant(
    MultibodyPlantConfig(
        time_step=2e-3 # indicates that the solver should use a 500Hz timestep
        ),builder=builder)
parser = Parser(plant)
parser.package_map().AddPackageXml(ur_pkg)

model_idx = parser.AddModels(ur_path)[0]

# weld the robot to the workspace or else it would just fall
# plant.WeldFrames(plant.world_frame(), plant.GetFrameByName("base_link"))
# finish editing the plant
plant.Finalize()

# add our feedback controller block into the system diagram
controller = builder.AddSystem(FeedbackControllerDrakeSimWrapper())

# connect the input and output ports
builder.Connect(controller.GetOutputPort("tau_m"), plant.get_actuation_input_port())
builder.Connect(plant.get_state_output_port(), controller.GetInputPort('robot_state'))

# log some data
state_logger = LogVectorOutput(plant.get_state_output_port(), builder)
control_logger = LogVectorOutput(controller.GetOutputPort("tau_m"), builder)

# connect the meshcat visualizer
AddDefaultVisualization(builder, meshcat)

# Finalize and Build the Diagram
diagram = builder.Build()

# diagram_context = diagram.CreateDefaultContext()
# robot_context = diagram.GetMutableSubsystemContext(plant, diagram_context)
simulator = Simulator(diagram)   # create simulator FIRST
#-------- ArmUp- sim----------------------------
# Get the simulator's own context (not a separate one)
sim_context    = simulator.get_mutable_context()
robot_context  = diagram.GetMutableSubsystemContext(plant, sim_context)

# NOW set your initial joint positions — this actually affects the sim
q0 = np.array([0.0, -1.57,  1.57, -1.57, -1.57, 0.0])  # adjust to move height
plant.SetPositions(robot_context, q0)


# # simulate the system
# simulator = Simulator(diagram)

#-----------------------------------------------------------------------


meshcat.StartRecording()# these will add playback and video record buttons to meshcat
simulator.set_target_realtime_rate(1)
simulator.AdvanceTo(50) # final time to simulate to
meshcat.PublishRecording()

# se up plots
state_log = state_logger.FindLog(simulator.get_context())
contr_log = control_logger.FindLog(simulator.get_context())

state_data = state_log.data().transpose()
contr_data = contr_log.data().transpose()

state_times = state_log.sample_times()
contr_times = contr_log.sample_times()

np.savetxt("state_data.csv", state_data, fmt='%.18e', delimiter=",")
np.savetxt("contr_data.csv", contr_data, fmt='%.18e', delimiter=",")
np.savetxt("state_times.csv", state_times, fmt='%.18e', delimiter=",")
np.savetxt("contr_times.csv", contr_times, fmt='%.18e', delimiter=",")

# ----------------------------- change from here
# Reconstruct end-effector position from logged states
# -----------------------------
tool_frame = plant.GetFrameByName("tool0")
ee_xyz = np.zeros((len(state_times), 3))


for k in range(len(state_times)):
    qk = state_data[k, :6]
    qdk = state_data[k, 6:12]
    plant.SetPositionsAndVelocities(robot_context, np.hstack((qk, qdk)))
    ee_xyz[k, :] = tool_frame.CalcPoseInWorld(robot_context).translation()


# -----------------------------
# Joint positions
# -----------------------------
plt.figure(figsize=(10, 6))
for i in range(6):
    plt.plot(state_times, state_data[:, i], label=f"q{i+1}")
plt.xlabel("Time [s]")
plt.ylabel("Joint position [rad]")
plt.title("Joint Positions vs Time")
plt.grid(True)
plt.legend()
plt.tight_layout()


# -----------------------------
# Joint velocities
# -----------------------------
plt.figure(figsize=(10, 6))
for i in range(6):
    plt.plot(state_times, state_data[:, 6+i], label=f"qd{i+1}")
plt.xlabel("Time [s]")
plt.ylabel("Joint velocity [rad/s]")
plt.title("Joint Velocities vs Time")
plt.grid(True)
plt.legend()
plt.tight_layout()


# -----------------------------
# Torque commands
# -----------------------------
plt.figure(figsize=(10, 6))
for i in range(6):
    plt.plot(contr_times, contr_data[:, i], label=f"tau{i+1}")
plt.axhline(25.0, color='k', linestyle='--', linewidth=1, label='torque limit')
plt.axhline(-25.0, color='k', linestyle='--', linewidth=1)
plt.xlabel("Time [s]")
plt.ylabel("Torque [Nm]")
plt.title("Joint Torque Commands vs Time")
plt.grid(True)
plt.legend()
plt.tight_layout()


# -----------------------------
# End-effector XYZ
# -----------------------------
plt.figure(figsize=(10, 6))
plt.plot(state_times, ee_xyz[:, 0], label="x")
plt.plot(state_times, ee_xyz[:, 1], label="y")
plt.plot(state_times, ee_xyz[:, 2], label="z")
plt.xlabel("Time [s]")
plt.ylabel("Position [m]")
plt.title("End-Effector Position vs Time")
plt.grid(True)
plt.legend()
plt.tight_layout()


# -----------------------------
# XY trajectory
# -----------------------------
plt.figure(figsize=(7, 7))
plt.plot(ee_xyz[:, 0], ee_xyz[:, 1], label="actual EE path")
plt.xlabel("X [m]")
plt.ylabel("Y [m]")
plt.title("End-Effector XY Path")
plt.axis("equal")
plt.grid(True)
plt.legend()
plt.tight_layout()


plt.show()
#--------------------
from mpl_toolkits.mplot3d import Axes3D


# -------------------------------------------------
# Reconstruct ACTUAL end-effector path from states
# -------------------------------------------------
tool_frame = plant.GetFrameByName("tool0")
ee_xyz = np.zeros((len(state_times), 3))


for k in range(len(state_times)):
    qk = state_data[k, :6]
    qdk = state_data[k, 6:12]
    plant.SetPositionsAndVelocities(robot_context, np.hstack((qk, qdk)))
    ee_xyz[k, :] = tool_frame.CalcPoseInWorld(robot_context).translation()


# -------------------------------------------------
# Build DESIRED waypoint path from HW5_P8 logic
# -------------------------------------------------
start_pt = ee_xyz[0, :]
end_pt = ee_xyz[-1, :]


x0, y0, z0 = start_pt
w = 0.18
h = 0.18
z_rect = z0 + 0.08


# Change this block to match your controller's flat rectangle
desired_waypoints = np.array([
    [x0,         y0,          z0],   # start corner
    [x0 - w,     y0,          z0],   # top-left
    [x0 - w,     y0 - h,      z0],   # bottom-left
    [x0,         y0 - h,      z0],   # bottom-right
    [x0,         y0,          z0],   # back to start
])


center_pt = np.array([x0 - 0.5*w, y0 - 0.5*h, z_rect])


# -------------------------------------------------
# 3D plot: ACTUAL vs DESIRED
# -------------------------------------------------
fig = plt.figure(figsize=(11, 8))
ax = fig.add_subplot(111, projection='3d')


# Actual EE path
ax.plot(
    ee_xyz[:, 0],
    ee_xyz[:, 1],
    ee_xyz[:, 2],
    color='blue',
    linewidth=2.5,
    label='Actual EE path'
)


# Desired waypoint path
ax.plot(
    desired_waypoints[:, 0],
    desired_waypoints[:, 1],
    desired_waypoints[:, 2],
    'k--',
    linewidth=1.8,
    label='Desired waypoint path'
)


# Desired waypoint markers
ax.scatter(
    desired_waypoints[:, 0],
    desired_waypoints[:, 1],
    desired_waypoints[:, 2],
    color='black',
    s=35,
    label='Waypoints'
)


# Start / end markers
ax.scatter(
    start_pt[0], start_pt[1], start_pt[2],
    color='green', s=90, label='Start'
)
ax.scatter(
    end_pt[0], end_pt[1], end_pt[2],
    color='red', s=90, label='End'
)


# Center marker
ax.scatter(
    center_pt[0], center_pt[1], center_pt[2],
    color='magenta', s=140, marker='x', label='Center'
)


ax.set_xlabel("X [m]")
ax.set_ylabel("Y [m]")
ax.set_zlabel("Z [m]")
ax.set_title("3D End-Effector Path: Actual vs Desired")
ax.view_init(elev=25, azim=-60)
ax.legend()
plt.tight_layout()
plt.show()

#---------------------
from my_controller import FeedbackController
import numpy as np

ctrl = FeedbackController()

print("Simulation started")
print(f"nq={ctrl.nq}, nv={ctrl.nv}")

t = 0.0
dt = 0.002
T_final = 10.0

# Replace these with actual simulator states
q = np.zeros(ctrl.nq)
qd = np.zeros(ctrl.nv)

while t <= T_final:
    # Replace this with actual q, qd read from your simulator
    tau = ctrl.calc_control_effort(q, qd, t)

    # Replace this with actual simulator update / torque application
    # apply_tau_to_sim(tau)
    # q, qd = get_state_from_sim()

    t += dt

print("Simulation finished")

#ctrl.save_torque_plot("joint_torques_v6.png", show_plot=True)
#ctrl.save_cartesian_plot("cartesian_tracking_v6.png", show_plot=True)
ctrl.save_step_response_plot("step_response.png", show_plot=True)
# -------------------------------------------------
# Print distance to center point
# -------------------------------------------------
dist_to_center = np.linalg.norm(ee_xyz - center_pt.reshape(1, 3), axis=1)
closest_idx = np.argmin(dist_to_center)


print("Center point:", center_pt)
print("Closest actual EE point:", ee_xyz[closest_idx])
print("Minimum distance to center [m]:", dist_to_center[closest_idx])
print("Time of closest approach [s]:", state_times[closest_idx])

